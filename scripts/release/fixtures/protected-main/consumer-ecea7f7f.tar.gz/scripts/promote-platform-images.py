#!/usr/bin/env python3
"""Resolve Bifrost platform images and maintain infra-owned image pins."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import re
import subprocess
import sys
import tempfile
import time
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_LOCK_FILE = REPO_ROOT / "environments" / "poc" / "images.lock.yml"
DEFAULT_GROUP_VARS = REPO_ROOT / "ansible" / "group_vars" / "poc.yml"
DEFAULT_AKS_WORKER_DEPLOYMENT = REPO_ROOT / "k8s" / "poc" / "aks-worker-next" / "deployment.yaml"
DEFAULT_TALOS_WORKER_DEPLOYMENTS = (
    REPO_ROOT / "k8s" / "poc" / "talos-worker" / "deployment.yaml",
    REPO_ROOT / "k8s" / "poc" / "talos-worker" / "deployment-t440.yaml",
    REPO_ROOT / "k8s" / "poc" / "talos-worker" / "deployment-backup.yaml",
)
DEFAULT_AKS_APP_DEPLOYMENTS = (
    REPO_ROOT / "k8s" / "poc" / "aks-app-next" / "deployment-api.yaml",
    REPO_ROOT / "k8s" / "poc" / "aks-app-next" / "migration-job.yaml",
    REPO_ROOT / "k8s" / "poc" / "aks-app-next" / "deployment-scheduler.yaml",
    REPO_ROOT / "k8s" / "poc" / "aks-app-next" / "deployment-client.yaml",
)
PLATFORM_REPO = "Midtown-Technology-Group/bifrost"
PLATFORM_WORKFLOW = "ci.yml"
IMAGE_REPOS = {
    "api": "ghcr.io/midtown-technology-group/bifrost-api",
    "client": "ghcr.io/midtown-technology-group/bifrost-client",
    "worker": "ghcr.io/midtown-technology-group/bifrost-worker",
}
RELEASE_TAG_RE = re.compile(r"^v[0-9]+\.[0-9]+\.[0-9]+(?:-[0-9A-Za-z][0-9A-Za-z.-]*)?$")
DEFAULT_WAIT_SECONDS = 20 * 60
DEFAULT_POLL_SECONDS = 15
_RELEASE_SPEC = importlib.util.spec_from_file_location("platform_release", REPO_ROOT / "scripts/platform_release.py")
release = importlib.util.module_from_spec(_RELEASE_SPEC)
_RELEASE_SPEC.loader.exec_module(release)


def run(command: list[str], *, check: bool = True) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(command, text=True, capture_output=True)
    if check and result.returncode != 0:
        stderr = result.stderr.strip() or result.stdout.strip()
        raise RuntimeError(f"{' '.join(command)} failed: {stderr}")
    return result


def github_json(path: str, query: dict[str, str] | None = None) -> Any:
    token = os.getenv("GH_TOKEN") or os.getenv("GITHUB_TOKEN")
    if not token:
        raise RuntimeError("GH_TOKEN or GITHUB_TOKEN is required for GitHub API access")

    url = f"https://api.github.com{path}"
    if query:
        url = f"{url}?{urllib.parse.urlencode(query)}"
    request = urllib.request.Request(
        url,
        headers={
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {token}",
            "X-GitHub-Api-Version": "2022-11-28",
        },
    )
    with urllib.request.urlopen(request, timeout=30) as response:
        return json.loads(response.read().decode("utf-8"))


def workflow_runs(
    limit: int = 20,
    *,
    branch: str | None = "main",
    commit: str | None = None,
    event: str | None = "push",
) -> list[dict[str, Any]]:
    query = {"per_page": str(limit)}
    if event is not None:
        query["event"] = event
    if branch is not None:
        query["branch"] = branch
    if commit is not None:
        query["head_sha"] = commit
    payload = github_json(
        f"/repos/{PLATFORM_REPO}/actions/workflows/{PLATFORM_WORKFLOW}/runs",
        query,
    )
    runs = []
    for run_info in payload.get("workflow_runs", []):
        runs.append(
            {
                "databaseId": run_info.get("id"),
                "runAttempt": run_info.get("run_attempt"),
                "status": run_info.get("status"),
                "conclusion": run_info.get("conclusion"),
                "createdAt": run_info.get("created_at"),
                "headSha": run_info.get("head_sha"),
                "headBranch": run_info.get("head_branch"),
                "event": run_info.get("event"),
                "displayTitle": run_info.get("display_title"),
                "url": run_info.get("html_url"),
            }
        )
    return runs


def latest_push_run() -> dict[str, Any]:
    runs = workflow_runs(limit=1)
    if not runs:
        raise RuntimeError(f"No {PLATFORM_WORKFLOW} push runs found for {PLATFORM_REPO} main")
    run_info = runs[0]
    publication = verified_queue_publication(run_info)
    if publication is not None:
        return publication
    if run_info["status"] != "completed" or run_info["conclusion"] != "success":
        raise RuntimeError(
            "Latest platform main push workflow is not promotable: "
            f"{run_info['headSha'][:12]} concluded {run_info['conclusion']}"
        )
    return run_info


def verified_queue_publication(run_info: dict[str, Any]) -> dict[str, Any] | None:
    """Use the completed exact-commit queue gate and official main publisher.

    The remaining post-merge CI lanes repeat the already gated commit. They may
    still run, but their completion need not delay promotion of published images.
    A failed/cancelled main run, other branch, tag, or different queue SHA cannot
    use this path. Image digest resolution and deployment gates remain separate.
    """
    source_sha = run_info.get("headSha", "")
    if (
        run_info.get("event") != "push"
        or run_info.get("headBranch") != "main"
        or run_info.get("status") != "in_progress"
        or run_info.get("conclusion") is not None
        or re.fullmatch(r"[0-9a-f]{40}", source_sha) is None
    ):
        return None
    queues = workflow_runs(limit=50, branch=None, commit=source_sha, event="merge_group")
    queue = next((item for item in queues if (
        item.get("headSha") == source_sha
        and item.get("event") == "merge_group"
        and item.get("headBranch", "").startswith("gh-readonly-queue/main/")
        and item.get("status") == "completed"
        and item.get("conclusion") == "success"
    )), None)
    if queue is None:
        return None
    payload = github_json(
        f"/repos/{PLATFORM_REPO}/actions/runs/{run_info['databaseId']}/jobs",
        {"per_page": "100", "filter": "latest"},
    )
    jobs = payload.get("jobs", [])
    if payload.get("total_count") != len(jobs):
        return None
    publishers = [item for item in jobs if item.get("name") == "Build Dev Images"]
    if len(publishers) != 1:
        return None
    publisher = publishers[0]
    if (
        publisher.get("head_sha") != source_sha
        or publisher.get("status") != "completed"
        or publisher.get("conclusion") != "success"
    ):
        return None
    return {**run_info, "verifiedPublication": {
        "queueRunId": queue["databaseId"], "publisherJobId": publisher["id"],
    }}


def _run_status_message(run_info: dict[str, Any]) -> str:
    conclusion = run_info.get("conclusion") or "pending"
    return (
        f"{run_info['headSha'][:12]} status={run_info['status']} "
        f"conclusion={conclusion}"
    )


def successful_run_for_sha(
    source_sha: str,
    *,
    branch: str | None = "main",
    event: str | None = "push",
    wait_seconds: int = DEFAULT_WAIT_SECONDS,
    poll_seconds: int = DEFAULT_POLL_SECONDS,
    allow_queue_publication: bool = True,
) -> dict[str, Any]:
    source_sha = source_sha.lower()
    deadline = time.monotonic() + wait_seconds
    last_status = "not found"

    while True:
        for run_info in workflow_runs(limit=50, branch=branch, commit=source_sha, event=event):
            if (not run_info["headSha"].lower().startswith(source_sha)
                    or (branch is not None and run_info.get("headBranch") != branch)
                    or (event is None and run_info.get("event") not in {"push", "workflow_dispatch"})):
                continue

            last_status = _run_status_message(run_info)
            if run_info["status"] == "completed" and run_info["conclusion"] == "success":
                return run_info
            if run_info["status"] == "completed":
                raise RuntimeError(
                    "Platform workflow for "
                    f"{run_info['headSha'][:12]} concluded {run_info['conclusion']}"
                )
            publication = verified_queue_publication(run_info) if branch == "main" and allow_queue_publication else None
            if publication is not None:
                return publication
            break

        if time.monotonic() >= deadline:
            raise RuntimeError(
                f"No successful platform workflow found for {source_sha} "
                f"within {wait_seconds}s; last status: {last_status}"
            )

        print(
            f"Waiting for platform workflow for {source_sha[:12]}: {last_status}",
            file=sys.stderr,
            flush=True,
        )
        time.sleep(poll_seconds)


def full_commit_sha(source_sha: str) -> str:
    commit = github_json(f"/repos/{PLATFORM_REPO}/commits/{source_sha}")
    return commit["sha"]


def latest_stable_tag() -> str:
    published = github_json(f"/repos/{PLATFORM_REPO}/releases/latest")
    tag = published.get("tag_name", "")
    if published.get("draft") or published.get("prerelease") or not release.STABLE_TAG_RE.fullmatch(tag):
        raise RuntimeError("Latest published release is not a stable vMAJOR.MINOR.PATCH release")
    return tag


def verified_release_manifest(run_info, release_tag, image_data):
    with tempfile.TemporaryDirectory(prefix="bifrost-release-") as directory:
        artifact_name = f"release-manifest-{release_tag}-attempt-{run_info['runAttempt']}"
        inventory = github_json(f"/repos/{PLATFORM_REPO}/actions/runs/{run_info['databaseId']}/artifacts",
                                {"name": artifact_name, "per_page": "100"})
        artifacts = inventory.get("artifacts")
        if not isinstance(artifacts, list) or inventory.get("total_count", len(artifacts)) > len(artifacts):
            raise RuntimeError("Release artifact inventory is incomplete")
        matches = [artifact for artifact in artifacts if artifact.get("name") == artifact_name]
        if len(matches) > 1:
            raise RuntimeError("Release artifact identity is ambiguous")
        if matches and matches[0].get("expired") is False:
            run(["gh", "run", "download", str(run_info["databaseId"]), "--repo", PLATFORM_REPO,
                 "--name", artifact_name, "--dir", directory])
        else:
            # Published release assets outlive Actions artifact retention. They must
            # still pass the same signed-subject and exact run/attempt validation.
            published = github_json(f"/repos/{PLATFORM_REPO}/releases/tags/{release_tag}")
            names = ("release-manifest.json", "release-manifest.json.sigstore.json")
            if (published.get("tag_name") != release_tag or published.get("draft") is not False
                    or published.get("prerelease") is not False or published.get("immutable") is not True
                    or any(sum(asset.get("name") == name and asset.get("state") == "uploaded"
                               for asset in published.get("assets", [])) != 1 for name in names)):
                raise RuntimeError("Published stable release manifest assets are unavailable or ambiguous")
            run(["gh", "release", "download", release_tag, "--repo", PLATFORM_REPO,
                 "--pattern", names[0], "--pattern", names[1], "--dir", directory])
        path = Path(directory) / "release-manifest.json"
        bundle = Path(directory) / "release-manifest.json.sigstore.json"
        if path.stat().st_size > 65536 or bundle.stat().st_size > 1024 * 1024:
            raise RuntimeError("Release manifest or attestation exceeds its size bound")
        run(["gh", "attestation", "verify", str(path), "--bundle", str(bundle),
             "--repo", PLATFORM_REPO,
             "--source-ref", "refs/tags/" + release_tag,
             "--source-digest", run_info["headSha"],
             "--cert-identity", f"https://github.com/{PLATFORM_REPO}/.github/workflows/ci.yml@refs/tags/{release_tag}"])
        raw = path.read_bytes()
        release.validate_manifest(json.loads(raw), tag=release_tag, source_sha=run_info["headSha"],
                                  run_id=run_info["databaseId"], run_attempt=run_info["runAttempt"],
                                  images=image_data)
        return raw, bundle.read_bytes()


def verified_production_manifest(run_info):
    """Select by full main SHA/run/attempt, never a mutable dev or short-SHA tag."""
    source = run_info["headSha"]
    attempt = run_info["runAttempt"]
    artifact = f"production-manifest-{source}-attempt-{attempt}"
    inventory = github_json(f"/repos/{PLATFORM_REPO}/actions/runs/{run_info['databaseId']}/artifacts",
                            {"name": artifact, "per_page": "100"})
    records = inventory.get("artifacts")
    if (not isinstance(records, list) or inventory.get("total_count") != len(records)
            or len(records) != 1 or records[0].get("name") != artifact or records[0].get("expired") is not False):
        raise ValueError("Exact production artifact unavailable or ambiguous; no development fallback")
    with tempfile.TemporaryDirectory(prefix="bifrost-production-") as directory:
        run(["gh", "run", "download", str(run_info["databaseId"]), "--repo", PLATFORM_REPO,
             "--name", artifact, "--dir", directory])
        path = Path(directory) / "production-manifest.json"
        bundle = Path(directory) / "production-manifest.json.sigstore.json"
        checksum = Path(directory) / "production-manifest.json.sha256"
        if path.stat().st_size > 65536 or checksum.stat().st_size > 256:
            raise ValueError("Production manifest/checksum exceeds its size bound")
        raw = path.read_bytes()
        if checksum.read_text().strip() != hashlib.sha256(raw).hexdigest() + "  production-manifest.json":
            raise ValueError("Production manifest checksum differs")
        manifest = release.validate_production_manifest(json.loads(raw), source_sha=source,
                    run_id=run_info["databaseId"], run_attempt=attempt)
        release.verify_attestation(path, bundle, manifest)
        release.qualify_production_manifest(manifest)
        provenance_bytes = release.validate_candidate_provenance(manifest,
            Path(directory) / release.CANDIDATE_PROVENANCE_NAME, verify=True)
        release.verify_registry_tuple(manifest)
        images = {}
        for role, record in manifest["images"].items():
            digest = record["repository"] + "@" + record["digest"]
            verify_runnable_image(digest)
            index = json.loads(run(["docker", "buildx", "imagetools", "inspect", digest, "--raw"]).stdout)
            observed = {}
            for item in index.get("manifests", []):
                platform = item.get("platform", {})
                if platform == {"architecture": "unknown", "os": "unknown"}:
                    continue
                name = platform.get("os", "") + "/" + platform.get("architecture", "")
                if name in observed:
                    raise ValueError("Duplicate production platform")
                observed[name] = item.get("digest")
            if observed != record["platforms"]:
                raise ValueError(f"Production {role} architecture inventory differs")
            images[role] = {"tag": digest, "digest": digest}
        return raw, bundle.read_bytes(), images, provenance_bytes


def image_ref_for_commit(image_repo: str, source_sha: str) -> str:
    return f"{image_repo}:sha-{source_sha[:7]}"


def image_ref_for_release_tag(image_repo: str, release_tag: str) -> str:
    if not RELEASE_TAG_RE.match(release_tag):
        raise ValueError(f"release tag must look like vMAJOR.MINOR.PATCH[-PRERELEASE] (got {release_tag!r})")
    return f"{image_repo}:{release_tag.removeprefix('v')}"


def repository_from_tagged_ref(image_ref: str) -> str:
    last_slash = image_ref.rfind("/")
    last_colon = image_ref.rfind(":")
    if last_colon <= last_slash:
        raise ValueError(f"image reference must include a tag (got {image_ref!r})")
    return image_ref[:last_colon]


def resolve_digest(image_ref: str) -> str:
    result = run(["docker", "buildx", "imagetools", "inspect", image_ref])
    match = re.search(r"^Digest:\s+(sha256:[0-9a-f]{64})$", result.stdout, re.MULTILINE)
    if not match:
        raise RuntimeError(f"Could not resolve digest for {image_ref}")
    pinned = f"{repository_from_tagged_ref(image_ref)}@{match.group(1)}"
    verify_runnable_image(pinned)
    return pinned


def verify_runnable_image(image_ref: str) -> None:
    """Reject OCI evidence artifacts; inspect the pinned amd64 image, never its subject."""
    if not re.fullmatch(r"[^@\s]+@sha256:[0-9a-f]{64}", image_ref):
        raise ValueError("Runnable image validation requires a digest-pinned reference")
    repository = image_ref.split("@", 1)[0]

    def inspect(reference: str) -> dict:
        result = run(["docker", "buildx", "imagetools", "inspect", reference, "--raw"])
        try:
            manifest = json.loads(result.stdout)
        except (ValueError, TypeError) as exc:
            raise RuntimeError("Published image manifest is not valid JSON") from exc
        if not isinstance(manifest, dict) or manifest.get("schemaVersion") != 2:
            raise RuntimeError("Published image manifest has an unsupported schema")
        if manifest.get("artifactType") or manifest.get("subject"):
            raise RuntimeError("Published reference is an evidence artifact, not a runnable image")
        return manifest

    manifest = inspect(image_ref)
    if manifest.get("mediaType") in {
        "application/vnd.oci.image.index.v1+json",
        "application/vnd.docker.distribution.manifest.list.v2+json",
    }:
        descriptors = manifest.get("manifests")
        if not isinstance(descriptors, list) or any(not isinstance(item, dict) for item in descriptors):
            raise RuntimeError("Published image index has invalid descriptors")
        candidates = [item for item in descriptors if item.get("platform") == {
            "os": "linux", "architecture": "amd64",
        } and not item.get("artifactType") and not item.get("annotations", {}).get(
            "vnd.docker.reference.type")]
        if len(candidates) != 1 or not re.fullmatch(
            r"sha256:[0-9a-f]{64}", str(candidates[0].get("digest", ""))
        ):
            raise RuntimeError("Published image index requires exactly one runnable linux/amd64 image")
        manifest = inspect(repository + "@" + candidates[0]["digest"])
    if manifest.get("mediaType") not in {
        "application/vnd.oci.image.manifest.v1+json",
        "application/vnd.docker.distribution.manifest.v2+json",
    } or not isinstance(manifest.get("config"), dict) or manifest["config"].get("mediaType") not in {
        "application/vnd.oci.image.config.v1+json",
        "application/vnd.docker.container.image.v1+json",
    }:
        raise RuntimeError("Published reference has no runnable image configuration")
    layers = manifest.get("layers")
    allowed_layers = {
        "application/vnd.oci.image.layer.v1.tar",
        "application/vnd.oci.image.layer.v1.tar+gzip",
        "application/vnd.oci.image.layer.v1.tar+zstd",
        "application/vnd.docker.image.rootfs.diff.tar.gzip",
    }
    if not isinstance(layers, list) or not layers or any(
        not isinstance(layer, dict) or layer.get("mediaType") not in allowed_layers for layer in layers
    ):
        raise RuntimeError("Published reference has no runnable filesystem layers")


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def parse_lock_images(lock_text: str) -> dict[str, str]:
    images: dict[str, str] = {}
    current: str | None = None
    for line in lock_text.splitlines():
        service_match = re.match(r"^\s{2}(api|client|aca_worker|worker):\s*$", line)
        if service_match:
            current = service_match.group(1)
            continue
        digest_match = re.match(r"^\s{4}digest:\s+(.+)\s*$", line)
        if current and digest_match:
            images[current] = digest_match.group(1).strip().strip('"')
    return images


def parse_lock_image_records(lock_text: str) -> dict[str, dict[str, str]]:
    records: dict[str, dict[str, str]] = {}
    current: str | None = None
    for line in lock_text.splitlines():
        service_match = re.match(r"^\s{2}(api|client|aca_worker|worker):\s*$", line)
        if service_match:
            current = service_match.group(1)
            records.setdefault(current, {})
            continue
        field_match = re.match(r"^\s{4}(tag|digest):\s+(.+)\s*$", line)
        if current and field_match:
            records[current][field_match.group(1)] = field_match.group(2).strip().strip('"')
    return records


def load_lock_images(lock_file: Path) -> dict[str, str]:
    if not lock_file.exists():
        return {}
    return parse_lock_images(read_text(lock_file))


def load_lock_image_records(lock_file: Path) -> dict[str, dict[str, str]]:
    if not lock_file.exists():
        return {}
    return parse_lock_image_records(read_text(lock_file))


def live_env_images(host: str) -> dict[str, str]:
    known_hosts_sink = "NUL" if os.name == "nt" else "/dev/null"
    command = [
        "ssh",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=10",
        "-o",
        "StrictHostKeyChecking=no",
        "-o",
        f"UserKnownHostsFile={known_hosts_sink}",
        host,
        "sudo sed -n '/^BIFROST_.*_IMAGE=/p' /etc/bifrost/compose-nonsecret.env",
    ]
    result = run(command)
    images: dict[str, str] = {}
    key_map = {
        "BIFROST_API_IMAGE": "api",
        "BIFROST_CLIENT_IMAGE": "client",
    }
    for line in result.stdout.splitlines():
        key, _, value = line.partition("=")
        if key in key_map:
            images[key_map[key]] = value.strip()
    return images


def render_lock(run_info: dict[str, Any], image_data: dict[str, dict[str, str]]) -> str:
    promoted_at = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    source_sha = run_info["headSha"]
    source_kind = run_info.get("sourceKind", "branch")
    source_ref = run_info.get("sourceRef", "main")
    run_id = run_info["databaseId"]
    return "\n".join(
        [
            "environment: poc",
            "source:",
            f"  repository: {PLATFORM_REPO}",
            f"  kind: {source_kind}",
            f"  ref: {source_ref}",
            f"  commit: {source_sha}",
            f"  workflow: {PLATFORM_WORKFLOW}",
            f"  run_id: {run_id}",
            *([f"  run_attempt: {run_info['runAttempt']}"] if source_kind == "protected-main" else []),
            f"  run_url: https://github.com/{PLATFORM_REPO}/actions/runs/{run_id}",
            *(
                [
                    f"  native_merge_queue_run_id: {run_info['verifiedPublication']['queueRunId']}",
                    f"  publication_job_id: {run_info['verifiedPublication']['publisherJobId']}",
                ]
                if "verifiedPublication" in run_info
                else []
            ),
            *([f"  release_manifest_sha256: {run_info['releaseManifestSha256']}"]
              if "releaseManifestSha256" in run_info else []),
            f'promoted_at: "{promoted_at}"',
            "images:",
            "  api:",
            f"    tag: {image_data['api']['tag']}",
            f"    digest: {image_data['api']['digest']}",
            "  client:",
            f"    tag: {image_data['client']['tag']}",
            f"    digest: {image_data['client']['digest']}",
            *(
                [
                    "  worker:",
                    f"    tag: {image_data['worker']['tag']}",
                    f"    digest: {image_data['worker']['digest']}",
                ]
                if "worker" in image_data
                else []
            ),
            "",
        ]
    )


def update_group_vars(group_vars: Path, image_data: dict[str, dict[str, str]]) -> None:
    text = read_text(group_vars)
    replacements = {
        "bifrost_api_image": image_data["api"]["digest"],
        "bifrost_client_image": image_data["client"]["digest"],
    }
    if "worker" in image_data:
        replacements["bifrost_baked_worker_image"] = image_data["worker"]["digest"]
    for key, value in replacements.items():
        pattern = rf'^{key}:\s+".*"$'
        replacement = f'{key}: "{value}"'
        text, count = re.subn(pattern, replacement, text, flags=re.MULTILINE)
        if count != 1:
            raise RuntimeError(f"Expected exactly one {key} entry in {group_vars}")
    group_vars.write_text(text, encoding="utf-8")


def update_aks_worker_deployment(deployment_file: Path, image_data: dict[str, dict[str, str]]) -> None:
    if "worker" not in image_data:
        return

    text = read_text(deployment_file)
    pattern = r"^(\s+image:\s+).+$"
    replacement = rf"\g<1>{image_data['worker']['digest']}"
    text, count = re.subn(pattern, replacement, text, count=1, flags=re.MULTILINE)
    if count != 1:
        raise RuntimeError(f"Expected exactly one worker image entry in {deployment_file}")
    deployment_file.write_text(text, encoding="utf-8")


def _aks_app_deployment_image_key(deployment_file: Path) -> str:
    if deployment_file.name == "deployment-client.yaml":
        return "client"
    return "api"


def update_aks_app_deployment(deployment_file: Path, image_data: dict[str, dict[str, str]]) -> None:
    image_key = _aks_app_deployment_image_key(deployment_file)
    if image_key not in image_data:
        return

    text = read_text(deployment_file)
    pattern = r"^(\s+image:\s+).+$"
    replacement = rf"\g<1>{image_data[image_key]['digest']}"
    text, count = re.subn(pattern, replacement, text, count=1, flags=re.MULTILINE)
    if count != 1:
        raise RuntimeError(f"Expected exactly one {image_key} image entry in {deployment_file}")
    deployment_file.write_text(text, encoding="utf-8")


def update_aks_app_deployments(
    deployment_files: tuple[Path, ...],
    image_data: dict[str, dict[str, str]],
) -> None:
    for deployment_file in deployment_files:
        update_aks_app_deployment(deployment_file, image_data)


def write_summary(
    run_info: dict[str, Any],
    image_data: dict[str, dict[str, str]],
    lock_images: dict[str, str],
    live_images: dict[str, str] | None,
    lock_file: Path,
) -> None:
    lines = [
        f"source_kind={run_info.get('sourceKind', 'branch')}",
        f"source_ref={run_info.get('sourceRef', 'main')}",
        f"source_commit={run_info['headSha']}",
        *([f"runtime_version={run_info['runtimeVersion']}"] if "runtimeVersion" in run_info else []),
        f"workflow_run=https://github.com/{PLATFORM_REPO}/actions/runs/{run_info['databaseId']}",
        f"api_tag={image_data['api']['tag']}",
        f"api_digest={image_data['api']['digest']}",
        f"client_tag={image_data['client']['tag']}",
        f"client_digest={image_data['client']['digest']}",
        f"worker_tag={image_data.get('worker', {}).get('tag', '')}",
        f"worker_digest={image_data.get('worker', {}).get('digest', '')}",
        f"lock_file={lock_file}",
        f"current_api={lock_images.get('api', '')}",
        f"current_client={lock_images.get('client', '')}",
        f"current_worker={lock_images.get('worker', '')}",
    ]
    if live_images is not None:
        lines.extend(
            [
                f"live_api={live_images.get('api', '')}",
                f"live_client={live_images.get('client', '')}",
            ]
        )
    print("\n".join(lines))

    github_output = os.environ.get("GITHUB_OUTPUT")
    if github_output:
        with open(github_output, "a", encoding="utf-8") as handle:
            for line in lines:
                key, _, value = line.partition("=")
                handle.write(f"{key}={value}\n")

    github_step_summary = os.environ.get("GITHUB_STEP_SUMMARY")
    if github_step_summary:
        with open(github_step_summary, "a", encoding="utf-8") as handle:
            handle.write("## Bifrost image promotion candidate\n\n")
            handle.write(f"- Source kind: `{run_info.get('sourceKind', 'branch')}`\n")
            handle.write(f"- Source ref: `{run_info.get('sourceRef', 'main')}`\n")
            handle.write(f"- Source commit: `{run_info['headSha']}`\n")
            if "runtimeVersion" in run_info:
                handle.write(f"- Baked runtime version: `{run_info['runtimeVersion']}` (protected-main, not stable)\n")
            handle.write(f"- Workflow run: https://github.com/{PLATFORM_REPO}/actions/runs/{run_info['databaseId']}\n")
            handle.write(f"- Current API: `{lock_images.get('api', '')}`\n")
            handle.write(f"- Current client: `{lock_images.get('client', '')}`\n")
            handle.write(f"- API: `{image_data['api']['digest']}`\n")
            handle.write(f"- Client: `{image_data['client']['digest']}`\n")
            if "worker" in image_data:
                handle.write(f"- Worker: `{image_data['worker']['digest']}`\n")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group()
    source.add_argument("--source-sha", help="Promote an exact protected-main SHA with its signed v2 tuple (no mutable tags).")
    source.add_argument("--release-tag", help="Promote a stable platform release tag, for example v3.0.0; defaults to latest stable release.")
    parser.add_argument("--allow-development", action="store_true", help="Explicitly permit reviewed development SHA/prerelease pins instead of a stable release.")
    parser.add_argument("--lock-file", type=Path, default=DEFAULT_LOCK_FILE)
    parser.add_argument("--group-vars", type=Path, default=DEFAULT_GROUP_VARS)
    parser.add_argument("--aks-worker-deployment", type=Path, help="Explicit legacy AKS worker manifest to update; routine promotion leaves AKS unchanged.")
    parser.add_argument(
        "--talos-worker-deployment",
        type=Path,
        nargs="+",
        default=list(DEFAULT_TALOS_WORKER_DEPLOYMENTS),
        help="Talos worker deployment manifests to pin to the promoted worker digest.",
    )
    parser.add_argument(
        "--aks-app-deployments",
        type=Path,
        nargs="+",
        default=None,
        metavar="DEPLOYMENT",
        help="Explicit legacy AKS app manifests to update; routine promotion leaves AKS unchanged.",
    )
    parser.add_argument(
        "--worker-image",
        help=(
            "Digest-pinned baked worker image to write to images.lock.yml, Ansible, "
            "and the AKS and Talos worker deployments. If omitted, the worker image published by platform CI is used."
        ),
    )
    parser.add_argument(
        "--worker-image-tag",
        help="Human-readable baked worker tag to record in images.lock.yml when --worker-image is supplied.",
    )
    parser.add_argument("--write", action="store_true", help="Update the lock file and Ansible group vars.")
    parser.add_argument("--live-host", help="SSH host for live VM comparison, for example bifrostops@20.9.81.122.")
    parser.add_argument("--skip-live", action="store_true", help="Skip live VM comparison even when a host is configured.")
    parser.add_argument(
        "--wait-seconds",
        type=int,
        default=DEFAULT_WAIT_SECONDS,
        help="Seconds to wait for a requested source SHA workflow to finish.",
    )
    parser.add_argument(
        "--poll-seconds",
        type=int,
        default=DEFAULT_POLL_SECONDS,
        help="Seconds between workflow status checks for a requested source SHA.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        ordinary = bool(args.source_sha and not args.allow_development)
        if ordinary and (not re.fullmatch(r"[0-9a-f]{40}", args.source_sha) or args.worker_image):
            raise ValueError("Ordinary production requires a full source SHA and one atomic worker tuple")
        if not args.source_sha and not args.release_tag and not args.allow_development:
            args.release_tag = latest_stable_tag()
        stable = bool(args.release_tag and release.STABLE_TAG_RE.fullmatch(args.release_tag))
        if args.release_tag and not stable and not args.allow_development:
            raise ValueError("Production requires a stable release tag; prerelease requires --allow-development")
        if stable and args.worker_image:
            raise ValueError("A stable release cannot override its attested worker image")
        if args.source_sha:
            source_sha = full_commit_sha(args.source_sha)
            run_info = successful_run_for_sha(
                source_sha,
                wait_seconds=args.wait_seconds,
                poll_seconds=args.poll_seconds,
                allow_queue_publication=not ordinary,
            )
            run_info["sourceKind"] = "protected-main" if ordinary else "commit"
            run_info["sourceRef"] = source_sha
        elif args.release_tag:
            source_sha = full_commit_sha(args.release_tag)
            run_info = successful_run_for_sha(
                source_sha,
                branch=args.release_tag,
                event=None,
                wait_seconds=args.wait_seconds,
                poll_seconds=args.poll_seconds,
            )
            run_info["sourceKind"] = "release"
            run_info["sourceRef"] = args.release_tag
        else:
            run_info = latest_push_run()
            source_sha = run_info["headSha"]
            run_info["sourceKind"] = "branch"
            run_info["sourceRef"] = "main"

        image_data: dict[str, dict[str, str]] = {}
        for service, image_repo in (() if ordinary else IMAGE_REPOS.items()):
            tag = (
                image_ref_for_release_tag(image_repo, args.release_tag)
                if args.release_tag
                else image_ref_for_commit(image_repo, source_sha)
            )
            image_data[service] = {"tag": tag, "digest": resolve_digest(tag)}

        manifest_bytes = bundle_bytes = provenance_bytes = None
        if ordinary:
            manifest_bytes, bundle_bytes, image_data, provenance_bytes = verified_production_manifest(run_info)
            run_info["releaseManifestSha256"] = hashlib.sha256(manifest_bytes).hexdigest()
            run_info["runtimeVersion"] = json.loads(manifest_bytes)["version"]
        elif stable:
            manifest_bytes, bundle_bytes = verified_release_manifest(run_info, args.release_tag, image_data)
            run_info["releaseManifestSha256"] = hashlib.sha256(manifest_bytes).hexdigest()

        lock_records = load_lock_image_records(args.lock_file)
        lock_images = {service: record["digest"] for service, record in lock_records.items() if "digest" in record}
        if args.worker_image:
            verify_runnable_image(args.worker_image)
            image_data["worker"] = {
                "tag": args.worker_image_tag or args.worker_image,
                "digest": args.worker_image,
            }

        if lock_images and not args.write:
            for service, digest in lock_images.items():
                if service in image_data and digest != image_data[service]["digest"]:
                    print(
                        f"candidate differs from lock: {service} lock={digest} candidate={image_data[service]['digest']}",
                        file=sys.stderr,
                    )

        live_images: dict[str, str] | None = None
        if not args.skip_live:
            live_host = args.live_host or os.environ.get("BIFROST_POC_HOST")
            if live_host:
                live_images = live_env_images(live_host)
                for service in ("api", "client"):
                    locked = lock_images.get(service)
                    if locked and live_images.get(service) and live_images[service] != locked:
                        raise RuntimeError(
                            f"Live {service} image differs from infra lock: "
                            f"live={live_images[service]} lock={locked}"
                        )
                    candidate = image_data[service]["digest"]
                    live = live_images.get(service)
                    if live and live != candidate:
                        print(
                            f"candidate differs from live: {service} live={live} candidate={candidate}",
                            file=sys.stderr,
                        )

        if args.write:
            args.lock_file.parent.mkdir(parents=True, exist_ok=True)
            if manifest_bytes is not None:
                (args.lock_file.parent / release.MANIFEST_NAME).write_bytes(manifest_bytes)
                (args.lock_file.parent / release.BUNDLE_NAME).write_bytes(bundle_bytes)
            else:
                (args.lock_file.parent / release.MANIFEST_NAME).unlink(missing_ok=True)
                (args.lock_file.parent / release.BUNDLE_NAME).unlink(missing_ok=True)
            if provenance_bytes is not None:
                (args.lock_file.parent / release.CANDIDATE_PROVENANCE_NAME).write_bytes(provenance_bytes)
            else:
                (args.lock_file.parent / release.CANDIDATE_PROVENANCE_NAME).unlink(missing_ok=True)
            args.lock_file.write_text(render_lock(run_info, image_data), encoding="utf-8")
            update_group_vars(args.group_vars, image_data)
            if args.aks_worker_deployment is not None:
                update_aks_worker_deployment(args.aks_worker_deployment, image_data)
            for talos_worker_deployment in args.talos_worker_deployment:
                update_aks_worker_deployment(talos_worker_deployment, image_data)
            if args.aks_app_deployments is not None:
                update_aks_app_deployments(tuple(args.aks_app_deployments), image_data)

        write_summary(run_info, image_data, lock_images, live_images, args.lock_file)
        return 0
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
