"""Nonsecret, immutable platform release identity shared by promotion and receipts."""
from __future__ import annotations

import hashlib
import base64
import json
import re
import subprocess
import tempfile
from pathlib import Path

PLATFORM_REPO = "Midtown-Technology-Group/bifrost"
STABLE_TAG_RE = re.compile(r"v(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)")
MANIFEST_NAME = "platform-release.json"
BUNDLE_NAME = "platform-release.json.sigstore.json"
CANDIDATE_PROVENANCE_NAME = "candidate-provenance.json"
SLSA = "https://slsa.dev/provenance/v1"
PRODUCTION_PREDICATE = "https://bifrost.midtowntg.com/attestations/production-manifest/v2"
MAIN_IDENTITY = f"https://github.com/{PLATFORM_REPO}/.github/workflows/ci.yml@refs/heads/main"


def validate_production_manifest(manifest, *, source_sha, run_id=None, run_attempt=None, images=None):
    """The additive v2 contract; never reinterpret a v1 dev binary as stable."""
    def keys(value, expected):
        return isinstance(value, dict) and set(value) == set(expected.split())

    if not keys(manifest, "schema_version product channel version tag source images compatibility build acceptance"):
        raise ValueError("Production manifest has missing or unknown fields")
    source, build = manifest["source"], manifest["build"]
    if (type(manifest["schema_version"]) is not int or manifest["schema_version"] != 2
            or manifest["product"] != "bifrost" or manifest["channel"] != "protected-main"
            or manifest["tag"] is not None
            or not isinstance(manifest["version"], str)
            or not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+-dev\.[0-9]+", manifest["version"])
            or not keys(source, "repository commit tree parent candidate_commit")
            or source["repository"] != PLATFORM_REPO or source["commit"] != source_sha
            or any(not isinstance(source[k], str) or not re.fullmatch(r"[0-9a-f]{40}", source[k])
                   for k in ("commit", "tree", "parent", "candidate_commit"))
            or not keys(build, "workflow run_id run_attempt event ref")
            or build["workflow"] != ".github/workflows/ci.yml" or build["event"] != "push"
            or build["ref"] != "refs/heads/main"
            or any(type(build[k]) is not int or build[k] < 1 for k in ("run_id", "run_attempt"))
            or (run_id is not None and build["run_id"] != run_id)
            or (run_attempt is not None and build["run_attempt"] != run_attempt)):
        raise ValueError("Production manifest differs from exact main source/run/attempt")
    records = manifest["images"]
    if not keys(records, "api client worker"):
        raise ValueError("Production manifest requires one complete component tuple")
    invocations = set()
    for role, record in records.items():
        platforms = {"linux/amd64", "linux/arm64"} if role == "worker" else {"linux/amd64"}
        if (not keys(record, "repository digest platforms candidate_provenance")
                or record["repository"] != f"ghcr.io/midtown-technology-group/bifrost-{role}"
                or not isinstance(record["digest"], str) or not re.fullmatch(r"sha256:[0-9a-f]{64}", record["digest"])
                or not isinstance(record["platforms"], dict) or set(record["platforms"]) != platforms
                or any(not isinstance(v, str) or not re.fullmatch(r"sha256:[0-9a-f]{64}", v)
                       for v in record["platforms"].values())):
            raise ValueError(f"Production manifest has invalid {role} identity/platforms")
        provenance = record["candidate_provenance"]
        if (not keys(provenance, "predicate_type invocation_uri run_id run_attempt invocation_commit workflow_commit workflow_ref checkout_commit checkout_tree bundle_sha256")
                or provenance["predicate_type"] != SLSA
                or any(type(provenance[k]) is not int or provenance[k] < 1 for k in ("run_id", "run_attempt"))
                or provenance["invocation_uri"] != f"https://github.com/{PLATFORM_REPO}/actions/runs/{provenance['run_id']}/attempts/{provenance['run_attempt']}"
                or any(not isinstance(provenance[k], str) or not re.fullmatch(r"[0-9a-f]{40}", provenance[k])
                       for k in ("invocation_commit", "workflow_commit", "checkout_commit", "checkout_tree"))
                or not isinstance(provenance["workflow_ref"], str)
                or not re.fullmatch(r"refs/pull/[1-9][0-9]*/merge|refs/heads/gh-readonly-queue/main/.+", provenance["workflow_ref"])
                or provenance["workflow_commit"] != provenance["invocation_commit"]
                or provenance["checkout_commit"] != source["candidate_commit"] or provenance["checkout_tree"] != source["tree"]
                or not isinstance(provenance["bundle_sha256"], str) or not re.fullmatch(r"[0-9a-f]{64}", provenance["bundle_sha256"])
                or (provenance["workflow_ref"].startswith("refs/heads/") and provenance["invocation_commit"] != provenance["checkout_commit"])):
            raise ValueError(f"Production {role} candidate provenance differs from source/invocation")
        invocations.add(tuple(provenance[k] for k in ("run_id", "run_attempt", "invocation_commit", "workflow_commit", "workflow_ref")))
        if images is not None and images.get(role, {}).get("digest") != record["repository"] + "@" + record["digest"]:
            raise ValueError(f"Production manifest differs from resolved {role} digest")
    if len(invocations) != 1:
        raise ValueError("Production tuple mixes candidate invocations/attempts")
    compatibility = manifest["compatibility"]
    if (not keys(compatibility, "cli_contract database rollback")
            or not keys(compatibility["cli_contract"], "current previous")
            or not keys(compatibility["database"], "migration_heads upgrade_required")
            or not keys(compatibility["rollback"], "supported reason")
            or compatibility["rollback"]["supported"] is not False
            or manifest["acceptance"] != {"kind": "signed-exact-tree-promotion", "components": ["api", "client", "worker"]}):
        raise ValueError("Production manifest lacks exact promotion/compatibility contract")
    validate_compatibility(manifest)
    return manifest


def github_json(path):
    result = subprocess.run(["gh", "api", f"repos/{PLATFORM_REPO}/{path}"],
                            check=True, capture_output=True, text=True, timeout=60)
    return json.loads(result.stdout)


def qualify_production_manifest(manifest):
    """Re-read the exact current attempt; an older green attempt cannot qualify it."""
    build, source = manifest["build"], manifest["source"]
    current = github_json(f"actions/runs/{build['run_id']}")
    if (current.get("id") != build["run_id"] or current.get("run_attempt") != build["run_attempt"]
            or current.get("status") != "completed" or current.get("conclusion") != "success"
            or current.get("event") != "push" or current.get("head_branch") != "main"
            or current.get("head_sha") != source["commit"] or current.get("path") != build["workflow"]
            or current.get("repository", {}).get("full_name") != PLATFORM_REPO
            or current.get("head_repository", {}).get("full_name") != PLATFORM_REPO):
        raise ValueError("Production requires completed successful exact main CI attempt")
    commit = github_json(f"commits/{source['commit']}")
    candidate = github_json(f"git/commits/{source['candidate_commit']}")
    comparison = github_json(f"compare/{source['commit']}...main")
    if (commit.get("sha") != source["commit"]
            or commit.get("commit", {}).get("verification", {}).get("verified") is not True
            or commit.get("commit", {}).get("tree", {}).get("sha") != source["tree"]
            or not commit.get("parents") or commit["parents"][0].get("sha") != source["parent"]
            or candidate.get("sha") != source["candidate_commit"] or candidate.get("tree", {}).get("sha") != source["tree"]
            or comparison.get("status") not in {"ahead", "identical"}):
        raise ValueError("Production source signature, ancestry or candidate tree differs")
    provenance = manifest["images"]["api"]["candidate_provenance"]
    if provenance["workflow_ref"].startswith("refs/pull/"):
        invocation = github_json(f"git/commits/{provenance['invocation_commit']}")
        parents = invocation.get("parents", [])
        if (invocation.get("sha") != provenance["invocation_commit"] or len(parents) != 2
                or parents[1].get("sha") != source["candidate_commit"]):
            raise ValueError("Candidate PR invocation must bind the exact checked-out second parent")
        workflow = ".github/workflows/ci.yml"
        selected_blob = github_json(f"contents/{workflow}?ref={source['commit']}")
        invoked_blob = github_json(f"contents/{workflow}?ref={provenance['workflow_commit']}")
        if not selected_blob.get("sha") or selected_blob["sha"] != invoked_blob.get("sha"):
            raise ValueError("Candidate invoked workflow differs from protected main")


def validate_candidate_provenance(manifest, path, *, verify=False):
    """Bind retained objects to signed hashes; never trust saved verificationResult."""
    if path.stat().st_size > 4 << 20:
        raise ValueError("Candidate provenance exceeds its size bound")
    retained_bytes = path.read_bytes()
    records = json.loads(retained_bytes)
    if (not isinstance(records, dict) or set(records) != {"api", "client", "worker"}
            or any(not isinstance(record, dict) for record in records.values())):
        raise ValueError("Candidate provenance requires the complete tuple")
    with tempfile.TemporaryDirectory(prefix="bifrost-candidate-proof-") as directory:
        for role, record in manifest["images"].items():
            proof = record["candidate_provenance"]
            retained = records[role].get("attestation")
            raw = json.dumps(retained, sort_keys=True, separators=(",", ":")).encode()
            if (not isinstance(retained, dict) or not isinstance(retained.get("bundle"), dict)
                    or hashlib.sha256(raw).hexdigest() != proof["bundle_sha256"]):
                raise ValueError(f"Retained {role} candidate bundle differs from signed hash")
            if not verify:
                continue
            bundle = Path(directory) / f"{role}.json"
            bundle.write_text(json.dumps(retained["bundle"]))
            identity = f"https://github.com/{PLATFORM_REPO}/.github/workflows/ci.yml@{proof['workflow_ref']}"
            result = subprocess.run([
                "gh", "attestation", "verify", "oci://" + record["repository"] + "@" + record["digest"],
                "--bundle", str(bundle), "--repo", PLATFORM_REPO, "--predicate-type", SLSA,
                "--cert-identity", identity, "--cert-oidc-issuer", "https://token.actions.githubusercontent.com",
                "--source-ref", proof["workflow_ref"], "--source-digest", proof["invocation_commit"],
                "--signer-digest", proof["workflow_commit"], "--deny-self-hosted-runners", "--format", "json",
            ], check=True, capture_output=True, text=True, timeout=180)
            if len(result.stdout) > 4 << 20:
                raise ValueError("Candidate verification result exceeds its size bound")
            results = json.loads(result.stdout)
            matched = False
            for verified in results:
                verified = verified["verificationResult"]
                statement = verified["statement"]
                cert = verified["signature"]["certificate"]
                predicate = statement["predicate"]
                definition = predicate["buildDefinition"]
                if (statement.get("predicateType") == SLSA
                        and statement.get("subject") == [{"name": record["repository"], "digest": {"sha256": record["digest"][7:]}}]
                        and cert.get("runInvocationURI") == proof["invocation_uri"]
                        and cert.get("sourceRepositoryDigest") == proof["invocation_commit"]
                        and cert.get("buildSignerDigest") == proof["workflow_commit"]
                        and all(cert.get(key) == value for key, value in {
                            "issuer": "https://token.actions.githubusercontent.com",
                            "sourceRepositoryURI": f"https://github.com/{PLATFORM_REPO}",
                            "sourceRepositoryRef": proof["workflow_ref"],
                            "subjectAlternativeName": identity, "buildSignerURI": identity,
                        }.items())
                        and predicate["runDetails"]["metadata"].get("invocationId") == proof["invocation_uri"]
                        and predicate["runDetails"]["builder"].get("id") == identity
                        and definition.get("buildType") == "https://actions.github.io/buildtypes/workflow/v1"
                        and definition["externalParameters"].get("workflow") == {"repository": f"https://github.com/{PLATFORM_REPO}", "path": ".github/workflows/ci.yml", "ref": proof["workflow_ref"]}
                        and definition["internalParameters"]["github"].get("event_name") == ("pull_request" if proof["workflow_ref"].startswith("refs/pull/") else "merge_group")
                        and definition.get("resolvedDependencies") == [{"uri": f"git+https://github.com/{PLATFORM_REPO}@{proof['workflow_ref']}", "digest": {"gitCommit": proof["invocation_commit"]}}]):
                    matched = True
            if not matched:
                raise ValueError(f"Verified {role} candidate identity differs from signed tuple")
    return retained_bytes


def verify_registry_tuple(manifest):
    """Verify the same signed predicate on all three immutable registry subjects."""
    for role, record in manifest["images"].items():
        image = record["repository"] + "@" + record["digest"]
        result = subprocess.run([
            "cosign", "verify-attestation", "--certificate-identity", MAIN_IDENTITY,
            "--certificate-oidc-issuer", "https://token.actions.githubusercontent.com",
            "--certificate-github-workflow-sha", manifest["source"]["commit"],
            "--certificate-github-workflow-trigger", "push", "--type", PRODUCTION_PREDICATE, image,
        ], check=True, capture_output=True, text=True, timeout=180)
        if len(result.stdout) > 4 << 20:
            raise ValueError("Registry tuple evidence exceeds its size bound")
        try:
            decoded = json.loads(result.stdout)
            envelopes = decoded if isinstance(decoded, list) else [decoded]
        except json.JSONDecodeError:
            envelopes = [json.loads(line) for line in result.stdout.splitlines() if line.strip()]
        matched = False
        for envelope in envelopes:
            if envelope.get("payloadType") != "application/vnd.in-toto+json":
                raise ValueError("Registry tuple has an unknown envelope")
            statement = json.loads(base64.b64decode(envelope["payload"], validate=True))
            if (statement.get("_type") in {"https://in-toto.io/Statement/v0.1", "https://in-toto.io/Statement/v1"}
                    and statement.get("predicateType") == PRODUCTION_PREDICATE
                    and statement.get("subject") == [{"name": record["repository"],
                                                      "digest": {"sha256": record["digest"][7:]}}]
                    and statement.get("predicate") == manifest):
                matched = True
        if not matched:
            raise ValueError(f"Registry {role} subject lacks the exact signed tuple")


def validate_manifest(manifest, *, tag, source_sha, run_id=None, run_attempt=None, images=None):
    if not STABLE_TAG_RE.fullmatch(tag):
        raise ValueError("Production release requires a stable vMAJOR.MINOR.PATCH tag")
    if (type(manifest.get("schema_version")) is not int or manifest["schema_version"] != 1 or manifest.get("product") != "bifrost"
            or manifest.get("version") != tag[1:] or manifest.get("tag") != tag
            or manifest.get("source") != {"repository": PLATFORM_REPO, "commit": source_sha}
            or not re.fullmatch(r"[0-9a-f]{40}", source_sha)):
        raise ValueError("Release manifest identity differs from the selected tag/source")
    build = manifest.get("build", {})
    if (build.get("workflow") != ".github/workflows/ci.yml"
            or any(type(build.get(key)) is not int or build[key] < 1 for key in ("run_id", "run_attempt"))
            or (run_id is not None and build["run_id"] != run_id)
            or (run_attempt is not None and build["run_attempt"] != run_attempt)):
        raise ValueError("Release manifest build differs from the exact tag CI run/attempt")
    records = manifest.get("images", {})
    if set(records) != {"api", "client", "worker"}:
        raise ValueError("Release manifest requires the complete API/client/worker tuple")
    for role, record in records.items():
        repository = f"ghcr.io/midtown-technology-group/bifrost-{role}"
        if (record.get("repository") != repository
                or not re.fullmatch(r"sha256:[0-9a-f]{64}", record.get("digest", ""))):
            raise ValueError(f"Release manifest has an invalid {role} image identity")
        if images is not None and images.get(role, {}).get("digest") != repository + "@" + record["digest"]:
            raise ValueError(f"Release manifest differs from resolved {role} digest")
    validate_compatibility(manifest)
    if manifest.get("acceptance") != {"kind": "container-content-smoke", "platform": "linux/amd64",
                                      "components": ["api", "client", "worker"]}:
        raise ValueError("Release manifest lacks exact-digest amd64 component acceptance")
    return manifest


def validate_compatibility(manifest):
    compatibility = manifest.get("compatibility", {})
    cli = compatibility.get("cli_contract", {})
    database = compatibility.get("database", {})
    heads = database.get("migration_heads", [])
    rollback = compatibility.get("rollback", {})
    if ("previous" not in cli or type(cli.get("current")) is not int or cli["current"] < 1
            or (cli.get("previous") is not None and (type(cli["previous"]) is not int or cli["previous"] < 1))
            or not isinstance(heads, list) or not heads
            or any(not isinstance(head, str) or not re.fullmatch(r"[A-Za-z0-9_]+", head) for head in heads)
            or len(set(heads)) != len(heads)
            or type(database.get("upgrade_required")) is not bool
            or type(rollback.get("supported")) is not bool
            or not isinstance(rollback.get("reason"), str) or not rollback["reason"].strip()):
        raise ValueError("Release manifest lacks CLI, database or rollback compatibility metadata")


def verify_attestation(manifest_file: Path, bundle_file: Path, manifest):
    if not bundle_file.is_file() or bundle_file.stat().st_size > 1024 * 1024:
        raise ValueError("Stored release attestation is missing or exceeds its size bound")
    tag, source_sha = manifest["tag"], manifest["source"]["commit"]
    ref = "refs/heads/main" if manifest.get("channel") == "protected-main" else "refs/tags/" + tag
    command = ["gh", "attestation", "verify", str(manifest_file), "--bundle", str(bundle_file),
               "--repo", PLATFORM_REPO,
               "--source-ref", ref, "--source-digest", source_sha,
               "--cert-identity", f"https://github.com/{PLATFORM_REPO}/.github/workflows/ci.yml@{ref}"]
    result = subprocess.run(command, check=False, capture_output=True, text=True)
    if result.returncode:
        raise ValueError("Stored release attestation failed verification against the exact tag/source")


def parse_release_lock(text):
    """Accept the promoter's unambiguous stable-lock subset, never YAML duplicates."""
    top, source, images = {}, {}, {}
    section = role = None
    for line in text.splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        match = re.fullmatch(r"( *)([a-z_][a-z_0-9]*):(?: (.+))?", line)
        if not match:
            raise ValueError("Stable image lock contains unsupported syntax")
        indent, key, value = len(match[1]), match[2], match[3]
        if indent == 0:
            if key not in {"environment", "source", "promoted_at", "images"} or key in top:
                raise ValueError("Stable image lock has duplicate or unknown top-level fields")
            top[key] = value
            section, role = key, None
        elif section == "source" and indent == 2:
            if key in source or value is None:
                raise ValueError("Stable image lock has duplicate or empty source fields")
            source[key] = value
        elif section == "images" and indent == 2:
            if key not in {"api", "client", "worker"} or key in images or value is not None:
                raise ValueError("Stable image lock has duplicate or unknown image roles")
            images[key], role = {}, key
        elif section == "images" and indent == 4 and role is not None:
            if key not in {"tag", "digest"} or key in images[role] or value is None:
                raise ValueError("Stable image lock has duplicate or unknown image fields")
            images[role][key] = value
        else:
            raise ValueError("Stable image lock has unexpected nesting")
    if (set(top) != {"environment", "source", "promoted_at", "images"}
            or top["source"] is not None or top["images"] is not None
            or set(source) != ({"repository", "kind", "ref", "commit", "workflow", "run_id", "run_url", "release_manifest_sha256"}
                               | ({"run_attempt"} if source.get("kind") == "protected-main" else set()))
            or set(images) != {"api", "client", "worker"}
            or any(set(record) != {"tag", "digest"} for record in images.values())):
        raise ValueError("Stable image lock lacks its exact source/image fields")
    if (source["repository"] != PLATFORM_REPO or source["workflow"] != "ci.yml"
            or source["run_url"] != f"https://github.com/{PLATFORM_REPO}/actions/runs/{source['run_id']}"):
        raise ValueError("Stable image lock publication identity is inconsistent")
    return source, images


def load_release_record(lock_file: Path, *, required=False, verify=False):
    """Bind reviewed local manifest bytes to the promoted source and digest lock."""
    text = lock_file.read_text()
    fields = dict(re.findall(r"^  (kind|ref|commit|run_id|release_manifest_sha256): ([^\n]+)$", text, re.MULTILINE))
    digest = fields.get("release_manifest_sha256")
    if not digest:
        if required or fields.get("kind") == "protected-main" or (fields.get("kind") == "release" and STABLE_TAG_RE.fullmatch(fields.get("ref", ""))):
            raise ValueError("Production requires an attested stable release lock; explicitly select the reviewed development override if needed")
        return None
    fields, images = parse_release_lock(text)
    digest = fields["release_manifest_sha256"]
    manifest_file = lock_file.parent / MANIFEST_NAME
    if manifest_file.stat().st_size > 65536:
        raise ValueError("Stored release manifest exceeds its size bound")
    raw = manifest_file.read_bytes()
    if not re.fullmatch(r"[0-9a-f]{64}", digest) or hashlib.sha256(raw).hexdigest() != digest:
        raise ValueError("Release manifest bytes differ from the reviewed image lock")
    candidate = fields.get("kind") == "protected-main"
    if not candidate and fields.get("kind") != "release":
        raise ValueError("Release manifest requires a release-tag image lock")
    for role, record in images.items():
        expected = record["digest"] if candidate else f"ghcr.io/midtown-technology-group/bifrost-{role}:{fields['ref'][1:]}"
        if record["tag"] != expected:
            raise ValueError(f"Stable release lock has inconsistent {role} tag")
    if candidate:
        if fields["ref"] != fields["commit"]:
            raise ValueError("Production candidate ref must equal its exact source")
        manifest = validate_production_manifest(json.loads(raw), source_sha=fields["commit"],
                                               run_id=int(fields["run_id"]), run_attempt=int(fields["run_attempt"]), images=images)
    else:
        manifest = validate_manifest(json.loads(raw), tag=fields.get("ref", ""),
                                     source_sha=fields.get("commit", ""),
                                     run_id=int(fields.get("run_id", "0")), images=images)
    if verify:
        verify_attestation(manifest_file, lock_file.parent / BUNDLE_NAME, manifest)
        if candidate:
            qualify_production_manifest(manifest)
    if candidate:
        validate_candidate_provenance(manifest, lock_file.parent / CANDIDATE_PROVENANCE_NAME, verify=verify)
    return {"sha256": digest, "manifest": manifest}


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lock-file", type=Path, default=Path(__file__).resolve().parents[1] / "environments/poc/images.lock.yml")
    parser.add_argument("--required", action="store_true")
    args = parser.parse_args()
    record = load_release_record(args.lock_file, required=args.required, verify=True)
    print(json.dumps(record, indent=2))
